<?php # Michael Wolfe PHP/MySQL Final - checkout.php
// This page inserts the order information into the table.
// This page would come after the billing process.
// This page assumes that the billing process worked (the money has been taken).

// Set the page title and include the HTML header
require ('includes/config.inc.php');
$page_title = 'Order Confirmation';
include ('includes/header.html');

// assume that the customer is logged in and that this page has access to the customer's ID:
if (isset($_SESSION['user_id']))
{
	$uid = $_SESSION['user_id'];	

	// Calculate the order total:
	$total = 0;
	foreach ($_SESSION['cart'] as $pid => $item) 
	{
		$qty = $item['quantity'];
		$price = $item['price'];
		$total += $qty * $price;
	}

	require ('../../mysqli_connect_final.php');	// connect to the database.

	// Turn autocommit off:
	mysqli_autocommit($dbc, FALSE);

	// Add the order to the orders table...
	$q = "INSERT INTO orders (user_id, total) VALUES ($uid, $total)";
	$r = mysqli_query($dbc, $q);
	if (mysqli_affected_rows($dbc) == 1) 
	{
		// Need the order ID:
		$oid = mysqli_insert_id($dbc);
		
		// insert the specified order contents into the database...
		// prepare the query:
		$q = "INSERT INTO order_contents (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
		$stmt = mysqli_prepare($dbc, $q);
		mysqli_stmt_bind_param($stmt, 'iiid', $oid, $pid, $qty, $price);
		
		// execute each query; count the total affected:
		$affected = 0;
		foreach ($_SESSION['cart'] as $pid => $item) 
		{
			$qty = $item['quantity'];
			$price = $item['price'];
			mysqli_stmt_execute($stmt);
			$affected += mysqli_stmt_affected_rows($stmt);
		}
	
		// Close this prepared statement:
		mysqli_stmt_close($stmt);
	
		// Report on the success...
		if ($affected == count($_SESSION['cart'])) //Success!
		{ 
			// Commit the transaction:
			mysqli_commit($dbc);
		
			// Clear the cart:
			unset($_SESSION['cart']);
		
			// Message to the customer:
			echo '<p>Thank you for your order. You will be notifed when the items ship.</p>';
		
			// Send emails and do whatever else.
			
			$body = "Thank you for your order. A confirmation email will be sent to you when your packages are shipped.";
			mail($_SESSION['email'], 'Order Confirmation', $body, 'From: mwolfe7@dtcc.edu');
			
		} else { // Rollback and report the problem.
	
			mysqli_rollback($dbc);
		
			echo '<p>Your order could not be processed due to a system error. You will be contacted in order to have the problem fixed. We apologize for the inconvenience.</p>';
		}
	} else { // Rollback an report the problem.

		mysqli_rollback($dbc);
		
		echo '<p>Your order could not be processed due to a system error. You will be contacted in order to have the problem fixed. We apologize for the inconvenience.</p>';	
	}
	mysqli_close($dbc);
} else{
	echo '<p>You need to log in.</p>';
}

include ('includes/footer.html');
?>	
