<?php # Michael Wolfe PHP/MySQL Final - browse_products.php
// This script retrieves all the records from the products table.
// Records are paginated in groups of 5 with sorting options available
require ('includes/config.inc.php');
$page_title = 'Browse Products';
include ('includes/header.html');
require (MYSQL); // Connect to the db.

// This first query is just to get the total count of rows
$sql = "SELECT COUNT(product_id) FROM products";
$query = mysqli_query($dbc, $sql);
$row = mysqli_fetch_row($query);

// Here we have the total row count
$rows = $row[0];
// This is the number of results we want displayed per page
$page_rows = 5;
// This tells us the page number of our last page
$last = ceil($rows / $page_rows);
// This makes sure $last cannot be less than 1
if ($last < 1)
{
    $last = 1;
}
// Establish the $pagenum variable
$pagenum = 1;
// Get pagenum from URL vars if it is present, else it is = 1
if (isset($_GET['s']))
{
    $pagenum = preg_replace('#[^0-9]#', '', $_GET['s']);
}
// This makes sure the page number isn't below 1, or more than our $last page
if ($pagenum < 1)
{
    $pagenum = 1;
} else if ($pagenum > $last)
{
    $pagenum = $last;
}
// Determine the sort...Default is by size.
$sort = (isset($_GET['sort'])) ? $_GET['sort'] : 'product_size';
// Determine the sorting order:
switch ($sort)
{
    case 'product_name':
        $order_by = 'product_name ASC';
        break;
    case 'product_desc':
        $order_by = 'product_desc ASC';
        break;
    case 'product_price':
        $order_by = 'product_price ASC';
        break;
    default:
        $order_by = 'product_size ASC';
        $sort = 'product_size';
        break;
}

// This sets the range of rows to query for the chosen $pagenum
$limit = 'LIMIT ' . ($pagenum - 1) * $page_rows . ',' . $page_rows;

// This is your query again, it is for grabbing just one page worth of rows by applying $limit, and sorted via $order_by
$sql = "SELECT product_id, product_name, product_desc, product_price, product_size, product_thumb_name FROM products ORDER BY $order_by $limit";
$query = mysqli_query($dbc, $sql);

// Establish the $paginationCtrls variable
$paginationCtrls = '';

// If there is more than 1 page worth of results...
if ($last != 1) 
{
    /* First we check if we are on page one. If we are then we don't need a link to
       the previous page or the first page so we do nothing. If we aren't then we
       generate links to the first page, and to the previous page. */
    if ($pagenum > 1) 
	{
        $previous = $pagenum - 1;
        $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?s=' . $previous . '&sort=' . $sort . '">Previous</a> &nbsp; &nbsp; ';
		// Render clickable number links that should appear on the left of the target page number
        for ($i = $pagenum - 4; $i < $pagenum; $i++) 
		{
            if ($i > 0) 
			{
                $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?s=' . $i . '&sort=' . $sort . '">' . $i . '</a> &nbsp; ';
            }
        }
    }
    // Render the target page number, but without it being a link
    $paginationCtrls .= '' . $pagenum . ' &nbsp; ';
    // Render clickable number links that should appear on the right of the target page number
    for ($i = $pagenum + 1; $i <= $last; $i++) 
	{
        $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?s=' . $i . '&sort=' . $sort . '">' . $i . '</a> &nbsp; ';
        if ($i >= $pagenum + 4) 
		{
            break;
        }
    }
    // This does the same as above, only checking if we are on the last page, and then generating the "Next"
    if ($pagenum != $last) 
	{
        $next = $pagenum + 1;
        $paginationCtrls .= ' &nbsp; &nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?s=' . $next . '&sort=' . $sort . '">Next</a> ';
    }
}

// create the table header
$tableHeader = '<table id="product_header" align="center" cellspacing="5" cellpadding="5" width="90%">
	<tr>
	<td align="left"></td>
	<td align="left"><b><a href="browse_products.php?sort=product_name">Name</a></b></td>
	<td align="left"><b><a href="browse_products.php?sort=product_desc">Desc.</a></b></td>
	<td align="left"><b><a href="browse_products.php?sort=product_size">Size</a></b></td>
	<td align="left"><b><a href="browse_products.php?sort=product_price">Price</a></b></td>
	</tr>';
// create the table data
$list = '';
// Fetch all the records:
while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) 
{
    $list .= '<tr>
		<td class="data" align="center"><img src="images/' . $row['product_thumb_name'] . '.png"/></td>
		<td class="data" align="center"><a href="view_product.php?pid=' . $row['product_id'] . '">' . $row['product_name'] . '</a></td>
		<td class="data" align="center">' . $row['product_desc'] . '</td>
		<td class="data" align="center">' . $row['product_size'] . '</td>
		<td class="data" align="center">$' . $row['product_price'] . '</td>
	</tr>';
} // End of WHILE loop.
$list .= '</table>'; // close the table.

// Close your database connection
mysqli_close($dbc);
?>
<div id="products">
    <h1>Products</h1>
	<p><?php echo $tableHeader; ?></p>
    <p><?php echo $list; ?></p>
    <div id="pagination_controls"><?php echo $paginationCtrls; ?></div>
</div>
<?php include('includes/footer.html'); ?>