<?php # Michael Wolfe PHP/MySQL Final - index.php
// This is the main page for the site.

// Set the page title and include the HTML header:
require ('includes/config.inc.php');
$page_title = 'Roslyn Rumpers!';
include ('includes/header.html');
?>
<h1>About Us...</h1><br>
<p>Welcome to RoslynRumpers! All wool soakers and longies have been lanolized so they are ready for wear when they arrive at your doorstep. RoslynRumpers woolies -- created from upcycled wool sweaters -- are designed with super thick wet zones to provide extra protection.</p>

<?php include ('includes/footer.html'); ?>