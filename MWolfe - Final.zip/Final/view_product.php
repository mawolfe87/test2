<?php # Michael Wolfe PHP/MySQL Final - view_product.php
// this page displays the details for a particular product.
require ('includes/config.inc.php');


$row = FALSE;	// Assume nothing!

if (isset($_GET['pid']) && filter_var($_GET['pid'], FILTER_VALIDATE_INT, array('min_range' => 1)) ) { // make sure there's a product ID!

	$pid = $_GET['pid'];
	
	// get the product info:
	require ('../../mysqli_connect_final.php'); // Connect to the database.
	$q = "SELECT product_id, product_name, product_price, product_size, product_image_name FROM products WHERE product_id=$pid";
	$r = mysqli_query ($dbc, $q);
	if (mysqli_num_rows($r) == 1) { // Good to go!
		
		// Fetch the information:
		$row = mysqli_fetch_array ($r, MYSQLI_ASSOC);
		$image = $row['product_image_name'];
		
		// Start the HTML page:
		$page_title = $row['product_name'];
		include ('includes/header.html');
		
		
		// Display a header:
		echo "<div align=\"center\">
		<b>{$row['product_name']}</b><br />";
		
		echo '<div align="center"><img src="images/' . $image . '.jpg"/></div>';
		
		// Print the size or a default message:
		echo (is_null($row['product_size'])) ? '(No size information available)' : $row['product_size'];
		
		echo "<br />\${$row['product_price']}
		<a href=\"add_cart.php?pid=$pid\">Add to Cart</a>";
		
	} // end of mysqli_num_rows() if
	
	mysqli_close($dbc);
	
} // End of $_GET['pid'] if

if (!$row) { // show error message
	$page_title = 'Error';
	include ('includes/header.html');
	echo '<div align="center">This page has been access in error!</div>';
}

// Complete the page:
include ('includes/footer.html');
?>
